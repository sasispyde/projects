var button=document.querySelector("button");
button.addEventListener("click",function f(){
    document.body.style.background="skyblue";
})