import React, { Component } from 'react';
import classes from './App.css';
import People from './People/People';


class App extends Component {
  state ={
    sasi:[
      {
        id:"5638",
        Name:"Sasi",
        age:"20"
      },
      {
        id:"23821",
        Name:"Kowshe",
        age:"18"
      }
    ],
    nameChange:false
  }
  switchNameHandler =(names) =>{
    this.setState({
          sasi:[
            {
              Name:names,
              age:"23"
            },
            {
              Name:"Kowshe",
              age:"18"
            }
          ],
        } 
      )
    }
    deleteHandler=(index)=>{
      const p=this.state.sasi;
      p.splice(index,1);
      this.setState({p:p});
    }

    nameChangeHandler = (event,id) => {
      const sIndex=this.state.sasi.findIndex(tex=>{
        return tex.id === id;
      });

      const pp={
        ...this.state.sasi[sIndex] 
      }
      pp.Name=event.target.value;

      const ppr=[...this.state.sasi];
      
      ppr[sIndex]=pp;
      // ppr[sIndex];

      this.setState({
        sasi:ppr
      } 
    )
    }
    toggleNameHandler= ()=>{
        const Does=this.state.nameChange
        this.setState({nameChange:!Does})      
    }
  render() {
    let per=null;
    if(this.state.nameChange){
      per=(
        <div>
          {this.state.sasi.map((s,index) =>{
            return <People
              click={this.deleteHandler.bind(this.index)}
              name={s.Name}
              age={s.age}
              key={s.id}
              change={(event)=>this.nameChangeHandler(event,s.id)}
              >
            </People>
          })}
        </div>
      );
    }

    return (
      <div className={classes.App}{...classes.body}>
       	<div>
       		<h1>Hello</h1>
           <p>this is from app.js</p>
           <button onClick={this.toggleNameHandler}>Show</button>
           {per}
       	</div>
      </div>
    );
  }
}

export default App;