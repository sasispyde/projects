import React,{ Component } from "react";

import LineChart from 'react-linechart';

import '../node_modules/react-linechart/dist/styles.css'

class Linechart extends Component {
    render() {

        const data =[{
            color:'blue',
            points:[{x:1,y:10},{x:2,y:12},{x:3,y:24},{x:4,y:42},{x:5,y:32},{x:6,y:12},{x:7,y:12},{x:8,y:32},{x:9,y:12},{x:10,y:22},{x:11,y:32},{x:12,y:42},{x:13,y:52},{x:14,y:62},{x:15,y:72},{x:16,y:82},{x:17,y:25},{x:18,y:21},{x:19,y:12},{x:20,y:2},{x:21,y:27},{x:22,y:82},{x:23,y:42},{x:24,y:2}]
        }
        ]
        return  (
            
                <LineChart 
                width ={500}
                height={400}
                data={data}
                xMin={'1'}
                xMax={'24'}
                yMin={'1'}
                yMax={'100'}
                />
            
        );
    }
}

export default Linechart;