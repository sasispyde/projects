import React, { Component } from 'react';

import Page1 from './Page1';

class App extends Component {
  render() {
    return (
      <div style={{width :'100%'}}>
        <Page1></Page1>
      </div>
    );
  }
}

export default App;
