import React from 'react';

class App extends React.Component {

 constructor(props) {
    super(props);
    this.state = {valueone: '',valuetwo: '',valuethree:'',valuefour:''};

    this.handleChangeone = this.handleChangeone.bind(this);
        this.handleChangetwo = this.handleChangetwo.bind(this);
        this.handleChangethree = this.handleChangethree.bind(this);
                this.handleChangefour = this.handleChangefour.bind(this);


    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChangeone(event) {
    this.setState({valueone: event.target.value});
  }

  handleChangetwo(event) {
    this.setState({valuetwo: event.target.value});
  }

  handleChangethree(event) {
    this.setState({valuethree: event.target.value});
  }

  handleChangefour(event) {
    this.setState({valuefour: event.target.value});
  }

  handleSubmit(event) {
      var myarray=new Array();

      myarray[0]=this.state.valueone;
      myarray[1]=this.state.valuetwo;
      myarray[2]=this.state.valuethree;
      myarray[3]=this.state.valuefour;
   
      document.write("<table border='1'/>");


      document.write("<tr><td style='width: 100px; color: red;'>Name</td>");
      document.write("<td style='width: 100px; color: red; text-align: right;'>Address</td>");
      document.write("<td style='width: 100px; color: red; text-align: right;'>Comment</td>");
      document.write("<td style='width: 100px; color: red; text-align: right;'>Color</td></tr>");

      

      document.write("<tr><td style='width: 100px; color: red;'>"+ myarray[0]+"</td>");
      document.write("<td style='width: 100px; color: red; text-align: right;'>"+myarray[1]+"</td>");
      document.write("<td style='width: 100px; color: red; text-align: right;'>"+myarray[2]+"</td>");
      document.write("<td style='width: 100px; color: red; text-align: right;'>"+myarray[3]+"</td></tr>");
    

    event.preventDefault();
  }

  render() 
  {
    return (
      <form onSubmit={this.handleSubmit}>
        <label>
          Name: <input type="text" value={this.state.valueone} onChange={this.handleChangeone} /><br/>
        </label>
         <label>
          Address : <input type="text" value={this.state.valuetwo} onChange={this.handleChangetwo} /><br/>
        </label>
        <label>
        Comment : <textarea value={this.state.valuethree} onChange={this.handleChangethree} /><br/>
        </label>
        <label>
          Pick your favorite color:
          <select value={this.state.valuefour} onChange={this.handleChangefour}>
            <option hidden selected></option>
            <option value="Green">Green</option>
            <option value="Red">Red</option>
            <option value="White">White</option>
            <option value="Blue">Blue</option>
          </select>
        </label>
        <input type="submit" value="Submit" />
      </form>
    );
  }
}

export default App;