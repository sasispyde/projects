var express=require("express");
var app=express();
var mongoose=require("mongoose");
var bodyparser=require("body-parser");
var method=require("method-override");
var passport=require("passport");
var local=require("passport-local");
var User=require("./models/user");
var Blog=require("./models/blog");
// var seedDB=require("./seed");
var Comment=require("./models/comment"); 
var flash=require("connect-flash");
// seedDB();
mongoose.connect("mongodb://Sasi:poorni007sasi5757@ds131902.mlab.com:31902/mydatabase2",{ useNewUrlParser: true });
app.set("view engine","ejs");
app.use(express.static("public"));
app.use(bodyparser.urlencoded({extended:"true"}));
app.use(method("_method"));
app.use(flash());
app.use(require("express-session")({
   secret:"sasi",
   resave:false,
   saveUninitialized:false
}));
app.use(passport.initialize());
app.use(passport.session());
passport.use(new local(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

app.use(function(req,res,next){
   res.locals.currentUser=req.user;
   res.locals.error=req.flash("error");
   res.locals.success=req.flash("success");
   next();
});

// var blogSchema=new mongoose.Schema({
//    title:String,
//    image:String,
//    content:String,
//    time:{type:Date,default:Date.now
//    }
// });
// var Blog=mongoose.model("Blog",blogSchema);
app.get("/",function(req, res) {
   req.flash("rest"," You successfully LogedIn")
    res.redirect("/blogs");
});
app.get("/blogs",function(req,res){
   Blog.find({},function(err,blogs){
      if(err){
         console.log(err);
      }
      else{
         res.render("index",{blogs:blogs,currentUser:req.user});
      }
   })
});
app.get("/blogs/new",islogedIn,function(req,res){
   res.render("new");
});

app.post("/blogs",islogedIn,function(req,res){
   Blog.create(req.body.blogs,function(err,newpost){
      if(err){
         console.log("Error...");
      }
      else{
         res.redirect("/blogs");
      }
   });
});

app.get("/blogs/:id",islogedIn,function(req, res) {
   Blog.findById(req.params.id).populate("comments").exec(function(err,data){
      if(err){
         console.log(err);
         res.redirect("/blogs");
      }
      else{
         res.render("show",{blog:data,currentUser:req.user});
      }
   });
});

app.get("/blogs/:id/edit",islogedIn,function(req, res) {
    Blog.findById(req.params.id,function(err,findBlog){
       if(err){
          console.log("Error");
          console.log(err);
       }
       else{
          res.render("edit",{blog:findBlog});
       }
    });
});
app.put("/blogs/:id",islogedIn,function(req,res){
   Blog.findByIdAndUpdate(req.params.id,req.params.blogs,function(err,updatedBlog){
      if(err){
         console.log("Error");
         req.flash("error","Something goes Wrong");
         res.redirect("/blogs");
      }
      else{
         req.flash("success","Successfully updated");
         res.redirect("/blogs/" +  req.params.id);
      }
   });
});

app.delete("/blogs/:id",islogedIn,function(req,res){
   Blog.findByIdAndRemove(req.params.id,function(err){
      if(err){
         req.flash("error","Cannot delete");
         res.redirect("/blogs");
      }
      else{
         req.flash("success","Successfully deleted");
         res.redirect("/blogs");
      }
   });
});

app.get("/register",function(req, res) {
    res.render("register");
});

app.post("/register",function(req,res){
   var newUser= new User({username:req.body.username});
   User.register(newUser,req.body.password,function(err,user){
      if(err){
         console.log(err);
         res.redirect("/register");
      }
      passport.authenticate("local")(req,res,function(){
         res.redirect("/blogs");
      });
   });
});

app.get("/login",function(req, res) {
    res.render("login");
});

app.post("/login",passport.authenticate("local",{
   successRedirect:"/blogs",
   failureRedirect:"/login",
}),function(req, res) {
    
});

app.get("/login",function(req, res) {
   res.render("/login"); 
});

app.get("/logout",function(req, res) {
    req.logout();
    req.flash("success","Successfully Loged out...");
    res.redirect("/blogs");
});

function islogedIn(req , res , next){
   if(req.isAuthenticated()){
      return next();
   }
   else{
      req.flash("error","please Login first");
      res.redirect("/login");
   }
}

app.get("/blogs/:id/comments/new",function(req, res) {
   Blog.findById(req.params.id,function(err, findBlog) {
       if(err){
          console.log(err);
       }
       else{
          res.render("comment",{blog:findBlog});
       }
   })
   // res.render("comment"); 
});

app.post("/blogs/:id/comment",function(req,res){
      Blog.findById(req.params.id,function(err, comment) {
          if(err){
             console.log(err);
             req.flash("error","Something goes Wrong");
             res.redirect("/blogs");
          }
          else{
             Comment.create({text:req.body.comment},function(err,comm){
                if(err){
                   console.log(err);
                }else{
                      comment.comments.push(comm);
                      comment.save();
                      req.flash("success","Successfully commented");
                      res.redirect("/blogs/"+ comment._id);
                  }
               }); 
            }
      })
});


app.listen(process.env.PORT,process.env.IP,function(){
   console.log("Server has started"); 
});
