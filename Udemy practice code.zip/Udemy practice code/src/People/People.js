import React from 'react';
import peoples from './People.css';

const people = (s) => {
    return (
        <div className={peoples.People}>
            <h3>THis is {s.name} and i am {s.age} Years old</h3>
            <button onClick={s.click}>DELETE</button>
            <input type="text" onChange={s.change} value={s.name}/>
            <span>{s.children}</span>
        </div>
    );
}

export default people;