import React , { Component }from 'react';

import Barchart from "./Barchart";

import Linechart from './LineChart'

class page1 extends Component {
    state ={
        ram:null,
        cpu:null,
    }
    render() {
        
        return(
            <div>
                <Barchart ></Barchart>
                <Linechart ></Linechart>
            </div>
        )
    }
}

export default page1;