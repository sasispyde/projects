var mongoose=require("mongoose");
var passpostlocal=require("passport-local-mongoose");

var UserSchema = new mongoose.Schema({
   userName:String,
   password:String
});

UserSchema.plugin(passpostlocal);

module.exports= mongoose.model("User",UserSchema);
