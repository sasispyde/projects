import React from 'react';

class App extends React.Component {
  render() {
    return (
      <div>
      <h1>Aravinth helloworld!!!</h1>
      
      <p> Generations of computer</p>
      </div>
    );
  }
}

export default App;
