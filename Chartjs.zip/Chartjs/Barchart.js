import React,{Component} from 'react';

import BarChart from 'react-bar-chart';
 
const data = [
  {text: 'RAM', value: 250}, 
  {text: 'Cpu', value: 300} 
];
 
const margin = {top: 20, right: 20, bottom: 30, left: 40};
 
class Example extends Component{
  getInitialState() {
    return { width: 500 };
  };
 
  handleBarClick(element, id){ 
    console.log(`The bin ${element.text} with id ${id} was clicked`);
  };
 
  render() {
        return (
            <div style={{width :'400px'}}>
                    <BarChart 
                      width={300}
                      height={300}
                      margin={margin}
                      data={data}
                      onBarClick={this.handleBarClick}/>
            </div>
    );
  }
};
 
export default Example