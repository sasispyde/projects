import React from 'react';

class App extends React.Component {
   constructor() {
      super();
      this.state = {
         data: 
         [
            {
               "id":1,
               "name":"Arun",
               "age":"20"
            },
            {
               "id":2,
               "name":"Bala",
               "age":"20"
            },
            {
               "id":3,
               "name":"Kumar",
               "age":"21"
            }
         ]
      }
   }
   render() {
      return (
         <div>
            <Header/>
            <table>
               <tr>
                  <td> SNo </td>
                  <td> SName </td>
                  <td> SAge</td>
               </tr>
               <tr>
                  {this.state.data.map((per,i) => <TableRow key = {i} 
                     data = {per} />)}
               </tr>
            </table>
         </div>
      );
   }
}
class Header extends React.Component {
   render() {
      return (
         <div>
            <h1>Details of Student</h1>
         </div>
      );
   }
}
class TableRow extends React.Component {
   render() {
      return (
         <tr>
            <td>{this.props.data.id}</td>
            <td>{this.props.data.name}</td>
            <td>{this.props.data.age}</td>
         </tr>
      );
   }
}
export default App;