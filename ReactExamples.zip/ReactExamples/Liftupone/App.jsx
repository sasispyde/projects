import React from 'react';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {activeArray:[0,0,0,0], name: ''};
    this.clickHandler = this.clickHandler.bind(this);
  }
  
  clickHandler(id, name) {
    var arr = [0, 0, 0, 0];
    arr[id] = 1;
    this.setState({
      name: name, 
      activeArray: arr
    });
  }
  
  render () {
    return (
      <div>
        <Button active={this.state.activeArray[0]} clickHandler={this.clickHandler} id={0} name="Home"/>
        <Button active={this.state.activeArray[1]} clickHandler={this.clickHandler} id={1} name="Product"/>
        <Button active={this.state.activeArray[2]} clickHandler={this.clickHandler} id={2} name="Service"/>
        <Button active={this.state.activeArray[3]} clickHandler= {this.clickHandler} id={3} name="Contact"/>
        <Details name={this.state.name}/>
      </div>
    );
  }
}


class Button extends React.Component {
  render () {
    return (
    <button onClick={() => {this.props.clickHandler(this.props.id, this.props.name)}} style={{color: this.props.active? 'red': 'blue'}}>{this.props.name}
    </button>
    );
  }
}


class Details extends React.Component {
  render () {
    return (
    <div>{this.props.name}
    </div>
    );
  }
}


export default App;