var React=require('react');
var ReactDOM=require('react-dom');

function Hello(props)
{
	return (<h1> hello ,{props.name}! </h1>);
}

ReactDOM.render(<Hello name ="jack" />, document.getElementById('app'));
