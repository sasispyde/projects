var name=prompt("Enter Your First Name");
var name1=prompt("Enter Your last Name");
var age=prompt("Enter Your age");
console.log("Your full name is " +name + name1);
console.log("you are "+age" years old");