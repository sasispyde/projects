var mongoose=require("mongoose");
var Blog=require("./models/blog");
var comment=require("./models/comment");
var data=[{
   title: "bug",
   image: "https://images.freeimages.com/images/large-previews/d93/gifts-5-1316929.jpg",
   content:"awasome",
}];
function seedDB(){
data.forEach(function(seed){
    Blog.create(seed,function(err,data){
        if(err){
            console.log(err);
        }else{
            comment.create({
              text:"great place",
            },function(err,comment){
                if(err){
                    console.log(err);
                }else{
                data.comments.push(comment);
                data.save();
                console.log("created");
                }
            });
        }
    });
});
}


module.exports = seedDB;
